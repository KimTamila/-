Programs Overview

Personal Information:
File: assigment1.dart
Description: This program prompts the user for their name, surname, and faculty, and then greets them.
Age Calculator:
File: task2.dart
Description: This program calculates the age of the user based on their year of birth.
Number Positivity Checker:
File: task3.dart
Description: This program checks whether a given number is positive, negative, or zero.
