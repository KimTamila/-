import 'dart:io';

void main() {
  print('Enter your name: ');
  String name = stdin.readLineSync()!;

  print('$name. Enter your surname: ');
  String surname = stdin.readLineSync()!;

  print('$surname. Enter your year of birth: ');
  int yearOfBirth = int.parse(stdin.readLineSync()!);

  int age = DateTime.now().year - yearOfBirth;

  print('Dear $name $surname, you are $age years old.');
}
